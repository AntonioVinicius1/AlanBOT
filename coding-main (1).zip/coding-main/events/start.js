console.log("ligando bot...");
// inicialização do Bot
console.log("Ligando em alguns segundos...")
